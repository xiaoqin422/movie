create view schedule_movie_hall_cinema as
select `movie_db`.`schedule`.`schedule_id`        AS `schedule_id`,
       `movie_db`.`schedule`.`hall_id`            AS `hall_id`,
       `movie_db`.`schedule`.`movie_id`           AS `movie_id`,
       `movie_db`.`schedule`.`schedule_startTime` AS `schedule_startTime`,
       `movie_db`.`schedule`.`schedule_price`     AS `schedule_price`,
       `movie_db`.`schedule`.`schedule_remain`    AS `schedule_remain`,
       `movie_db`.`schedule`.`schedule_state`     AS `schedule_state`,
       `movie_db`.`hall`.`hall_name`              AS `hall_name`,
       `movie_db`.`movie`.`movie_cn_name`         AS `movie_cn_name`,
       `movie_db`.`cinema`.`cinema_name`          AS `cinema_name`
from (((`movie_db`.`schedule` join `movie_db`.`hall` on ((`movie_db`.`schedule`.`hall_id` = `movie_db`.`hall`.`hall_id`))) join `movie_db`.`movie` on ((`movie_db`.`schedule`.`movie_id` = `movie_db`.`movie`.`movie_id`)))
         join `movie_db`.`cinema` on ((`movie_db`.`hall`.`cinema_id` = `movie_db`.`cinema`.`cinema_id`)));

