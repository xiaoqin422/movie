create view hall_cinema as
select `movie_db`.`hall`.`hall_id`          AS `hall_id`,
       `movie_db`.`hall`.`hall_name`        AS `hall_name`,
       `movie_db`.`hall`.`hall_capacity`    AS `hall_capacity`,
       `movie_db`.`hall`.`cinema_id`        AS `cid`,
       `movie_db`.`cinema`.`cinema_name`    AS `cinema_name`,
       `movie_db`.`cinema`.`cinema_address` AS `cinema_address`
from (`movie_db`.`cinema`
         join `movie_db`.`hall` on ((`movie_db`.`hall`.`cinema_id` = `movie_db`.`cinema`.`cinema_id`)));

